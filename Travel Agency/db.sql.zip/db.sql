-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 22, 2017 at 05:52 PM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `travel_agency`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `email_address` varchar(50) NOT NULL,
  `phone_number` varchar(13) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email_address` (`email_address`,`phone_number`,`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `first_name`, `last_name`, `email_address`, `phone_number`, `username`, `password`) VALUES
(1, 'mehreen', 'najm', 'mehreennajm2016@gmail.com', '0798287282', 'Admin@123swttCkjkj9p', 'Allahismylove@143swt'),
(8, 'Shamsia', 'Shaifeie', 'shamsia@gmail.com', '0798987987', 'Shamsia!2dfsd', 'A222C0ljsjkk'),
(7, 'lkjdf', 'ddf', 'dfs@gmail.com', '90834829384', 'saA98df', 'A87dfsf');

-- --------------------------------------------------------

--
-- Table structure for table `airlines`
--

CREATE TABLE IF NOT EXISTS `airlines` (
  `airline_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `service_name` varchar(70) DEFAULT NULL,
  `flight_id` int(11) NOT NULL,
  PRIMARY KEY (`airline_id`),
  KEY `flightss_fk` (`flight_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `airlines`
--

INSERT INTO `airlines` (`airline_id`, `name`, `service_name`, `flight_id`) VALUES
(1, 'Boying 380', 'Traveling Services', 1),
(4, 'boying3983', 'traveling', 7);

-- --------------------------------------------------------

--
-- Table structure for table `booking_form_issues`
--

CREATE TABLE IF NOT EXISTS `booking_form_issues` (
  `booking_id` int(11) NOT NULL DEFAULT '0',
  `customer_id` int(11) NOT NULL,
  `flight_id` int(11) NOT NULL,
  PRIMARY KEY (`booking_id`),
  KEY `ff_fk` (`flight_id`),
  KEY `cus_fk` (`customer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking_form_issues`
--


-- --------------------------------------------------------

--
-- Table structure for table `costumers_booking_form`
--

CREATE TABLE IF NOT EXISTS `costumers_booking_form` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `check_in` varchar(40) DEFAULT NULL,
  `check_out` varchar(40) DEFAULT NULL,
  `email_address` varchar(50) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `hotel_name` varchar(50) DEFAULT NULL,
  `children` int(11) DEFAULT NULL,
  `adults` int(11) DEFAULT NULL,
  `comfort_type` varchar(10) DEFAULT NULL,
  `no_of_rooms` int(11) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `costumers_booking_form`
--

INSERT INTO `costumers_booking_form` (`customer_id`, `first_name`, `last_name`, `country`, `city`, `check_in`, `check_out`, `email_address`, `phone_number`, `hotel_name`, `children`, `adults`, `comfort_type`, `no_of_rooms`) VALUES
(7, 'mehreen', 'najm', 'afg', 'kabul', '2017-11-15', '2017-11-27', 'mehren@gmail.com', '089803089', 'kabul', 0, 1, 'lux', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer_emails`
--

CREATE TABLE IF NOT EXISTS `customer_emails` (
  `customer_email_id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(30) NOT NULL,
  `email_address` varchar(50) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `body` text NOT NULL,
  PRIMARY KEY (`customer_email_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `customer_emails`
--

INSERT INTO `customer_emails` (`customer_email_id`, `fullname`, `email_address`, `subject`, `body`) VALUES
(9, 'dfdsfsd', 'mehren@gmail.com', 'fgfs', 'fsdfsfsdfsfsdfsd\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `flights`
--

CREATE TABLE IF NOT EXISTS `flights` (
  `flight_id` int(11) NOT NULL AUTO_INCREMENT,
  `flight_name` varchar(80) DEFAULT NULL,
  `no_of_passengers` int(11) DEFAULT NULL,
  `departure_time` date DEFAULT NULL,
  `arrival_time` date DEFAULT NULL,
  `airline_name` varchar(60) NOT NULL,
  PRIMARY KEY (`flight_id`),
  KEY `air_fk` (`airline_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `flights`
--

INSERT INTO `flights` (`flight_id`, `flight_name`, `no_of_passengers`, `departure_time`, `arrival_time`, `airline_name`) VALUES
(1, 'Kabul to Mazar', 40, '2017-11-13', '2017-11-14', 'Turkish airlines');

-- --------------------------------------------------------

--
-- Table structure for table `travel_agency`
--

CREATE TABLE IF NOT EXISTS `travel_agency` (
  `t_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `contract_customer_id` int(11) NOT NULL,
  PRIMARY KEY (`t_id`),
  KEY `costmer_fk` (`contract_customer_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `travel_agency`
--

INSERT INTO `travel_agency` (`t_id`, `name`, `address`, `phone`, `contract_customer_id`) VALUES
(1, 'SKY', 'SahrenawHajiyaqobsquare', 2147483647, 8);
